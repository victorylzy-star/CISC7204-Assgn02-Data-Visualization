CISC7204 Assignment 02 | Pair 11
MC65390 LIU ZHIYI; MC65426 Wang Haoyu

Submission documents
1. CISC7204-Assgn02-Pair11-RevisedProjectProposal.docx: formal English proposal.
2. CISC7204_Assignment02_Pair11_Analysis.ipynb: executed supporting notebook with embedded figures.
3. figures/: three standalone 300-dpi PNG figures.
4. data/: all CSV files required for offline reproduction; source links and original addresses retained.

How to reproduce
Extract this whole package. With Python 3 available, install requirements.txt in your own Python environment:
python -m pip install -r requirements.txt
Open the notebook from this package folder and run all cells in order.
Alternatively run: python reproduce_analysis.py
No network connection is required for the analysis after installing Matplotlib.
The source text includes Chinese; CSV files use UTF-8 with BOM.

The notebook reproduces preliminary findings and does not implement the complete future service-field audit described in the proposal. Do not interpret directory records or payment information display as street-wide business performance, actual usage, tourism flows or policy impacts.
Optional-credit eligibility and permitted upload formats must follow the actual course/platform instructions. No bonus points are asserted by this package.
