# Pair 11 companion analysis. Run from the extracted package folder.

from pathlib import Path
import csv, json, math
from collections import Counter
from html import escape
import matplotlib
# Headless reproduction: write PNG files only, never block on plt.show().
# Without this, a macOS/Windows GUI backend (e.g. "macosx") blocks the script.
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch, Rectangle
try:
    get_ipython().run_line_magic("matplotlib", "inline")
except NameError:
    pass

BASE = Path.cwd()
DATA = BASE / "data"
FIGURES = BASE / "figures"
FIGURES.mkdir(exist_ok=True)
if not (DATA / "shops_analysis.csv").is_file():
    raise FileNotFoundError("Open the notebook from the extracted package folder containing data/.")
def read_csv(name):
    with (DATA / name).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))
shops = read_csv("shops_analysis.csv")
candidates = read_csv("source4_consumer_candidates.csv")
iam = read_csv("source3_iam.csv")
dst = read_csv("source5_dst.csv")
mgto = read_csv("source2_mgto_full_titles.csv")
matches = read_csv("branch_matching.csv")
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10,
                     "axes.spines.top": False, "axes.spines.right": False,
                     "axes.titleweight": "bold", "savefig.facecolor": "white"})
BLUE, ORANGE, GREY = "#35648A", "#C87927", "#A7ADB4"
def save_figure(fig, name):
    fig.savefig(FIGURES / name, dpi=300, bbox_inches="tight")
    if matplotlib.get_backend().lower() != "agg":
        plt.show()
    plt.close(fig)
print("Loaded", len(shops), "sample records. Matplotlib", matplotlib.__version__)


# Data integrity checks for this fixed snapshot
assert len(shops) == 14 and len({r["shop_id"] for r in shops}) == 14
assert len(iam) == 29 and len({(r["name"], r["address"]) for r in iam}) == 29
assert len(candidates) == 15 and len(dst) == 2 and len(mgto) == 113
assert len(matches) == 14
assert all(r["dsedt_url"].startswith("https://www.dsedt.gov.mo/") for r in shops)
assert all(r["retrieved_date"] == "2026-10-25" for r in shops)
assert {r["display_name"] for r in mgto}.issuperset(
    {r["shop_name"] for r in shops if r["found_in_selected_mgto_catalog"] == "1"})
for r in shops:
    for key in ("shop_history_mentioned", "craft_transmission_mentioned", "innovation_mentioned"):
        assert r[key] in ("0", "1")
    if r["consumer_match_status"] != "已匹配":
        assert r["payment_display"] == ""
        assert r["electronic_display"] == "未确认"
assert {r["shop_id"] for r in shops if r["consumer_match_status"] != "已匹配"} == {"S03", "S12", "S14"}
print("Fixed-snapshot checks passed. These checks do not verify current business operation or live webpage accuracy.")


main = [r for r in shops if r["scope"] == "主街"]
confirmed = [r for r in shops if r["consumer_match_status"] == "已匹配"]
themes = [("shop_history_mentioned", "History"),
          ("craft_transmission_mentioned", "Transmission"),
          ("innovation_mentioned", "Innovation")]
categories = [("餐廳", "Restaurant"), ("零售", "Retail")]
full_counts = [sum(r["source_category"] == c for r in shops) for c, _ in categories]
main_counts = [sum(r["source_category"] == c for r in main) for c, _ in categories]
theme_counts = [sum(int(r[k]) for r in shops) for k, _ in themes]
mgto_detected = sum(int(r["found_in_selected_mgto_catalog"]) for r in shops)
payment_counts = [sum(r["electronic_display"] == state for r in shops)
                  for state in ("已展示", "未明示", "未确认")]
wallet_count = sum(r["wallet_display"] == "已展示" for r in confirmed)
assert full_counts == [9, 5] and main_counts == [6, 4]
assert theme_counts == [8, 7, 4] and payment_counts == [10, 1, 3]
assert len(confirmed) == 11 and wallet_count == 8 and mgto_detected == 13
print("Business categories, full sample:", dict(zip([v for _, v in categories], full_counts)))
print("Main street:", len(main), "records; categories:", main_counts)
print("Theme mentions (overlap allowed):", dict(zip([v for _, v in themes], theme_counts)))
print(f"MGTO selected-page name detection: {mgto_detected}/14 ({mgto_detected/14:.1%})")
print("Consumer branch matches:", len(confirmed), "; unresolved:", len(shops)-len(confirmed))
print(f"Electronic display among matched records: {payment_counts[0]}/11 ({payment_counts[0]/11:.1%})")
print(f"Explicit MPAY/Alipay/WeChat Pay among matched: {wallet_count}/11 ({wallet_count/11:.1%})")
print("IAM and DST matches:", sum(bool(r["iam_record_id"]) for r in shops), len(dst))
theme_cross = []
for category, label in categories:
    group = [r for r in shops if r["source_category"] == category]
    for key, theme in themes:
        n = sum(int(r[key]) for r in group)
        theme_cross.append({"category": label, "theme": theme,
                            "mentions": n, "denominator": len(group), "share": n/len(group)})
for row in theme_cross:
    print(f'{row["category"]:10} {row["theme"]:12} {row["mentions"]}/{row["denominator"]} = {row["share"]:.1%}')
saved_cross = read_csv("category_theme.csv")
assert [int(r["mentioned"]) for r in saved_cross] == [r["mentions"] for r in theme_cross]
assert all(math.isclose(float(a["proportion"]), b["share"]) for a,b in zip(saved_cross,theme_cross))


fig, axes = plt.subplots(1, 2, figsize=(12, 5.8))
ax = axes[0]
positions = list(range(2)); width = 0.34
bars1 = ax.bar([x-width/2 for x in positions], full_counts, width, color=BLUE, label="Full group (n=14)")
bars2 = ax.bar([x+width/2 for x in positions], main_counts, width, color=ORANGE, label="Main street subset (n=10)")
ax.set_xticks(positions, [label for _,label in categories])
ax.set_ylabel("Directory records"); ax.set_ylim(0, 11)
ax.set_title("A  Business categories")
ax.bar_label(bars1, padding=3); ax.bar_label(bars2, padding=3)
ax.legend(frameon=False, fontsize=9); ax.yaxis.set_major_locator(matplotlib.ticker.MaxNLocator(integer=True))
ax = axes[1]
for i, (cat,label) in enumerate(categories):
    part = [r for r in theme_cross if r["category"] == label]
    xs = [j + (i-0.5)*width for j in range(3)]
    bars = ax.bar(xs, [r["share"]*100 for r in part], width, color=[BLUE, ORANGE][i],
                  label=f'{label} (n={part[0]["denominator"]})')
    ax.bar_label(bars, labels=[f'{r["mentions"]}/{r["denominator"]}' for r in part], padding=3)
ax.set_xticks(range(3), [v for _,v in themes]); ax.set_ylim(0, 105)
ax.set_ylabel("Descriptions mentioning theme (%)"); ax.set_title("B  Cultural themes by category")
ax.legend(frameon=False, fontsize=9)
fig.suptitle("Figure 1  Business and cultural presentation in the fixed sample", fontsize=14, weight="bold")
fig.text(.06, .03, "Source: DSEDT directory extracts, 25 Oct 2026. Themes are preliminary researcher codes and may overlap.\n"
         "Zero means not explicitly mentioned; the sample does not represent all street businesses.", fontsize=9)
fig.subplots_adjust(bottom=.23, top=.82, wspace=.30)
save_figure(fig, "Figure01_business_and_culture.png")


fig, axes = plt.subplots(1, 2, figsize=(12, 5.8))
ax = axes[0]
bars = ax.bar(["Name detected", "Not detected"], [mgto_detected, len(shops)-mgto_detected], color=[BLUE,GREY], width=.58)
ax.set_title("A  Selected MGTO Central page"); ax.set_ylabel("Sample records (denominator 14)")
ax.set_ylim(0,16); ax.bar_label(bars, padding=3)
ax.yaxis.set_major_locator(matplotlib.ticker.MaxNLocator(integer=True))
ax = axes[1]
bars = ax.bar(["Displayed", "Not explicitly\ndisplayed", "Unresolved\nbranch"], payment_counts,
              color=[BLUE,GREY,ORANGE], width=.58)
ax.set_title("B  Electronic payment information"); ax.set_ylabel("Sample records (denominator 14)")
ax.set_ylim(0,16); ax.bar_label(bars, padding=3)
ax.yaxis.set_major_locator(matplotlib.ticker.MaxNLocator(integer=True))
fig.suptitle("Figure 2  Directory inclusion and service information display", fontsize=14, weight="bold")
fig.text(.06,.03,"Sources: MGTO selected Central page and DSEDT consumer directory, 25 Oct 2026.\n"
         "Among 11 matched branches: 10/11 (90.9%) display an electronic method or acceptance mark; 8/11 (72.7%)\n"
         "explicitly display MPAY, Alipay or WeChat Pay. Display is not actual payment acceptance or use.",fontsize=9)
fig.subplots_adjust(bottom=.25,top=.82,wspace=.30)
save_figure(fig, "Figure02_inclusion_and_payment_display.png")


fig, ax = plt.subplots(figsize=(11.5, 8.8))
colours = {"positive": "#D9E8F2", "not_shown": "#ECEFF2", "pending": "#FBE5C9"}
for i, r in enumerate(shops):
    texts = ["Name detected" if r["found_in_selected_mgto_catalog"] == "1" else "Not detected",
             "Matched" if r["consumer_match_status"] == "已匹配" else "Unresolved",
             {"已展示":"Displayed", "未明示":"Not explicit", "未确认":"Unresolved"}[r["electronic_display"]]]
    states = ["positive" if r["found_in_selected_mgto_catalog"] == "1" else "not_shown",
              "positive" if r["consumer_match_status"] == "已匹配" else "pending",
              {"已展示":"positive", "未明示":"not_shown", "未确认":"pending"}[r["electronic_display"]]]
    for j,(label,state) in enumerate(zip(texts,states)):
        ax.add_patch(Rectangle((j-.5,i-.5),1,1,facecolor=colours[state],edgecolor="white",linewidth=2))
        ax.text(j,i,label,ha="center",va="center",fontsize=10)
ax.set_xlim(-.5,2.5);ax.set_ylim(len(shops)-.5,-.5)
ax.set_xticks(range(3),["MGTO selected page\nname detection", "Consumer directory\nbranch identity", "Electronic payment\ndisplay"])
ax.xaxis.tick_top();ax.tick_params(axis="both",length=0,pad=9)
ax.set_yticks(range(len(shops)),[r["shop_id"] for r in shops])
for spine in ax.spines.values():spine.set_visible(False)
fig.suptitle("Figure 3  Record level checks and unresolved branches",fontsize=14,weight="bold",y=.97)
fig.text(.10,.04,"Fixed sample n=14; IDs link to shops_analysis.csv. Sources: MGTO and DSEDT, 25 Oct 2026.\n"
         "S03, S12 and S14 remain unresolved and are excluded from matched-branch payment percentages.\n"
         "Name detection does not confirm a branch. This is not a complete audit of all service fields.",fontsize=9)
fig.subplots_adjust(top=.85,bottom=.17,left=.10,right=.96)
save_figure(fig, "Figure03_record_level_matrix.png")


# Crosswalk: original source values remain available in the package.
print("ID | DSEDT business name | Main street status | Consumer branch status")
for r in shops:
    print(r["shop_id"],r["shop_name"],r["scope"],r["consumer_match_status"],sep=" | ")
print("\nRecords requiring particular attention:")
for r in shops:
    if r["shop_id"] in {"S01","S03","S12","S13","S14"}:
        print(r["shop_id"],r["match_note"],r["consumer_url"],sep=" | ")
summary = {"snapshot_date":"2026-10-25","sample_n":len(shops),"main_street_n":len(main),
           "restaurant_n":full_counts[0],"retail_n":full_counts[1],
           "mgto_selected_page_names":mgto_detected,"consumer_matched_n":len(confirmed),
           "electronic_displayed_n":payment_counts[0],"not_explicit_n":payment_counts[1],
           "unresolved_n":payment_counts[2],"explicit_wallet_n":wallet_count,
           "theme_mentions":dict(zip([label for _,label in themes],theme_counts))}
(BASE/"analysis_summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
print("\nSaved three figures and analysis_summary.json")
